-- =====================================================================
-- 모음달력: 전체 설치 SQL (migrations 001~007 을 순서대로 합친 파일)
-- Supabase 대시보드 > SQL Editor > New query 에 전부 붙여넣고 Run 하세요.
-- 여러 번 실행해도 안전합니다(이미 있는 테이블·정책·트리거는 건너뛰거나 다시 만듭니다).
-- =====================================================================

-- ---- 20261013000001_schema.sql ----
-- =====================================================================
-- 001. 스키마: profiles / calendars / calendar_members / events
-- Supabase 대시보드 > SQL Editor 에 001 → 004 순서대로 붙여넣어 실행하세요.
-- (한 번에 실행하려면 supabase/setup.sql 을 사용)
-- =====================================================================

-- 1) profiles : 구글 계정 1개 = 프로필 1개 (auth.users 와 1:1)
create table if not exists public.profiles (
  id          uuid primary key references auth.users(id) on delete cascade,
  nickname    text check (char_length(nickname) between 1 and 12),
  color       text not null default '#8E8E93' check (color ~ '^#[0-9A-Fa-f]{6}$'),
  avatar_url  text,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);
comment on column public.profiles.nickname is 'null 이면 온보딩(프로필 설정) 미완료';

-- 2) calendars : 공유 캘린더 방
create table if not exists public.calendars (
  id           uuid primary key default gen_random_uuid(),
  name         text not null check (char_length(name) between 1 and 30),
  invite_code  text not null unique check (invite_code ~ '^[A-Z2-9]{6}$'),
  group_color  text not null default '#FF6B35' check (group_color ~ '^#[0-9A-Fa-f]{6}$'),
  owner_id     uuid not null references public.profiles(id) on delete cascade,
  created_at   timestamptz not null default now()
);

-- 3) calendar_members : 소속과 역할
create table if not exists public.calendar_members (
  calendar_id  uuid not null references public.calendars(id) on delete cascade,
  user_id      uuid not null references public.profiles(id) on delete cascade,
  role         text not null default 'member' check (role in ('admin', 'member')),
  joined_at    timestamptz not null default now(),
  primary key (calendar_id, user_id)
);
create index if not exists calendar_members_user_idx on public.calendar_members (user_id);

-- 4) events : 일정
create table if not exists public.events (
  id           uuid primary key default gen_random_uuid(),
  calendar_id  uuid not null,
  author_id    uuid not null,
  title        text not null check (char_length(title) between 1 and 40),
  memo         text check (char_length(memo) <= 500),
  is_group     boolean not null default false,
  start_date   date not null,
  end_date     date not null,
  start_time   time,              -- null = 종일
  end_time     time,              -- '24:00' 허용 (자정까지)
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now(),
  -- 멤버가 추방/탈퇴하면 그 캘린더에 쓴 그 사람의 일정도 자동 삭제
  constraint events_author_member_fk foreign key (calendar_id, author_id)
    references public.calendar_members (calendar_id, user_id) on delete cascade,
  constraint events_date_order check (end_date >= start_date),
  constraint events_time_pair check ((start_time is null) = (end_time is null)),
  constraint events_time_order check (start_time is null or end_date > start_date or end_time > start_time),
  constraint events_max_span check (end_date - start_date <= 62)
);
create index if not exists events_calendar_start_idx on public.events (calendar_id, start_date);
create index if not exists events_calendar_end_idx   on public.events (calendar_id, end_date);
create index if not exists events_author_idx         on public.events (calendar_id, author_id);

-- updated_at 자동 갱신
create or replace function public.touch_updated_at() returns trigger
language plpgsql set search_path = public as $$
begin
  new.updated_at := now();
  return new;
end $$;

drop trigger if exists trg_profiles_touch on public.profiles;
create trigger trg_profiles_touch before update on public.profiles
  for each row execute function public.touch_updated_at();
drop trigger if exists trg_events_touch on public.events;
create trigger trg_events_touch before update on public.events
  for each row execute function public.touch_updated_at();

-- 구글 최초 로그인 시 프로필 행 자동 생성 (닉네임은 온보딩에서 입력)
create or replace function public.handle_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, avatar_url)
  values (new.id, new.raw_user_meta_data ->> 'avatar_url')
  on conflict (id) do nothing;
  return new;
end $$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
  for each row execute function public.handle_new_user();

-- 마지막 관리자는 강등·탈퇴·추방 불가 (캘린더 삭제로 인한 연쇄 삭제는 허용)
create or replace function public.guard_last_admin() returns trigger
language plpgsql set search_path = public as $$
begin
  if old.role = 'admin'
     and (tg_op = 'DELETE' or new.role <> 'admin')
     and exists (select 1 from public.calendars where id = old.calendar_id)
     and not exists (
       select 1 from public.calendar_members
       where calendar_id = old.calendar_id and role = 'admin' and user_id <> old.user_id
     ) then
    raise exception 'LAST_ADMIN' using hint = '다른 멤버를 관리자로 지정한 뒤 다시 시도하세요.';
  end if;
  return coalesce(new, old);
end $$;

drop trigger if exists trg_guard_last_admin on public.calendar_members;
create trigger trg_guard_last_admin before update or delete on public.calendar_members
  for each row execute function public.guard_last_admin();

-- ---- 20261013000002_rls.sql ----
-- =====================================================================
-- 002. Row Level Security
--  - 이용자: 같은 캘린더 조회 + 본인 일정(개인) 추가/수정/삭제
--  - 관리자: 캘린더 안의 모든 일정 수정/삭제, 단체 일정 등록, 멤버 관리
--  - 캘린더 생성/참여는 RPC(003) 전용 (insert 정책 없음)
-- =====================================================================
alter table public.profiles         enable row level security;
alter table public.calendars        enable row level security;
alter table public.calendar_members enable row level security;
alter table public.events           enable row level security;

-- 헬퍼: SECURITY DEFINER 라 RLS 재귀 없이 멤버십을 판단
create or replace function public.is_member(cal uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from calendar_members where calendar_id = cal and user_id = auth.uid()
  );
$$;

create or replace function public.is_admin(cal uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from calendar_members
    where calendar_id = cal and user_id = auth.uid() and role = 'admin'
  );
$$;

create or replace function public.shares_calendar_with(other uuid) returns boolean
language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from calendar_members a
    join calendar_members b on a.calendar_id = b.calendar_id
    where a.user_id = auth.uid() and b.user_id = other
  );
$$;

-- ---------------------------------------------------------------------
-- profiles : 본인 + 같은 캘린더 멤버만 조회, 수정은 본인 닉네임/색만
-- ---------------------------------------------------------------------
drop policy if exists profiles_select on public.profiles;
create policy profiles_select on public.profiles for select to authenticated
  using (id = auth.uid() or public.shares_calendar_with(id));
drop policy if exists profiles_update on public.profiles;
create policy profiles_update on public.profiles for update to authenticated
  using (id = auth.uid()) with check (id = auth.uid());

revoke insert, update, delete on public.profiles from anon, authenticated;
grant update (nickname, color) on public.profiles to authenticated;

-- ---------------------------------------------------------------------
-- calendars : 멤버만 조회, 관리자만 이름/강조색 변경·삭제
-- ---------------------------------------------------------------------
drop policy if exists calendars_select on public.calendars;
create policy calendars_select on public.calendars for select to authenticated
  using (public.is_member(id));
drop policy if exists calendars_update on public.calendars;
create policy calendars_update on public.calendars for update to authenticated
  using (public.is_admin(id)) with check (public.is_admin(id));
drop policy if exists calendars_delete on public.calendars;
create policy calendars_delete on public.calendars for delete to authenticated
  using (public.is_admin(id));

revoke insert, update on public.calendars from anon, authenticated;
grant update (name, group_color) on public.calendars to authenticated;

-- ---------------------------------------------------------------------
-- calendar_members : 멤버만 조회, 관리자만 역할 변경·추방, 본인은 나가기
-- ---------------------------------------------------------------------
drop policy if exists members_select on public.calendar_members;
create policy members_select on public.calendar_members for select to authenticated
  using (public.is_member(calendar_id));
drop policy if exists members_update on public.calendar_members;
create policy members_update on public.calendar_members for update to authenticated
  using (public.is_admin(calendar_id)) with check (public.is_admin(calendar_id));
drop policy if exists members_delete on public.calendar_members;
create policy members_delete on public.calendar_members for delete to authenticated
  using (public.is_admin(calendar_id) or user_id = auth.uid());

revoke insert, update on public.calendar_members from anon, authenticated;
grant update (role) on public.calendar_members to authenticated;

-- ---------------------------------------------------------------------
-- events
-- ---------------------------------------------------------------------
drop policy if exists events_select on public.events;
create policy events_select on public.events for select to authenticated
  using (public.is_member(calendar_id));

drop policy if exists events_insert on public.events;
create policy events_insert on public.events for insert to authenticated
  with check (
    author_id = auth.uid()
    and public.is_member(calendar_id)
    and (not is_group or public.is_admin(calendar_id))     -- 단체 일정은 관리자만
  );

drop policy if exists events_update on public.events;
create policy events_update on public.events for update to authenticated
  using (author_id = auth.uid() or public.is_admin(calendar_id))
  with check (
    (author_id = auth.uid() or public.is_admin(calendar_id))
    and (not is_group or public.is_admin(calendar_id))
  );

drop policy if exists events_delete on public.events;
create policy events_delete on public.events for delete to authenticated
  using (author_id = auth.uid() or public.is_admin(calendar_id));

-- 작성자/캘린더는 바꿀 수 없도록 컬럼 단위로 update 허용
revoke update on public.events from anon, authenticated;
grant update (title, memo, is_group, start_date, end_date, start_time, end_time)
  on public.events to authenticated;

-- ---- 20261013000003_rpc.sql ----
-- =====================================================================
-- 003. RPC (supabase.rpc 로 호출)
--  create_calendar / preview_calendar / join_calendar / regenerate_invite_code
-- =====================================================================

-- 6자리 초대코드: 헷갈리는 0/O, 1/I 를 뺀 32자 (32^6 ≈ 10.7억 조합)
create or replace function public.gen_invite_code() returns text
language plpgsql volatile set search_path = public as $$
declare
  chars text  := 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  -- gen_random_uuid() 는 암호학적 난수 기반, 앞 6바이트는 버전 비트가 없는 순수 난수
  b     bytea := decode(replace(gen_random_uuid()::text, '-', ''), 'hex');
  code  text  := '';
begin
  for i in 0..5 loop
    code := code || substr(chars, 1 + (get_byte(b, i) % 32), 1);
  end loop;
  return code;
end $$;

-- 캘린더 만들기: 캘린더 + 만든 사람을 admin 으로 등록 (한 트랜잭션)
create or replace function public.create_calendar(p_name text, p_color text default '#FF6B35')
returns uuid
language plpgsql security definer set search_path = public as $$
declare
  v_id uuid;
begin
  if auth.uid() is null then raise exception 'AUTH_REQUIRED'; end if;
  if not exists (select 1 from profiles where id = auth.uid() and nickname is not null) then
    raise exception 'PROFILE_REQUIRED';
  end if;

  loop
    begin
      insert into calendars (name, group_color, invite_code, owner_id)
      values (trim(p_name), coalesce(p_color, '#FF6B35'), gen_invite_code(), auth.uid())
      returning id into v_id;
      exit;
    exception when unique_violation then
      -- 초대코드 충돌 시 재시도
    end;
  end loop;

  insert into calendar_members (calendar_id, user_id, role) values (v_id, auth.uid(), 'admin');
  return v_id;
end $$;

-- 참여 전 미리보기 (멤버가 아니어도 이름·인원만 확인 가능)
create or replace function public.preview_calendar(p_code text)
returns table (id uuid, name text, group_color text, member_count bigint, already_member boolean)
language sql stable security definer set search_path = public as $$
  select c.id, c.name, c.group_color,
         (select count(*) from calendar_members m where m.calendar_id = c.id),
         exists (select 1 from calendar_members m where m.calendar_id = c.id and m.user_id = auth.uid())
  from calendars c
  where auth.uid() is not null and c.invite_code = upper(trim(p_code));
$$;

-- 초대코드로 참여 (이미 멤버면 그대로 통과)
create or replace function public.join_calendar(p_code text)
returns uuid
language plpgsql security definer set search_path = public as $$
declare
  v_id uuid;
begin
  if auth.uid() is null then raise exception 'AUTH_REQUIRED'; end if;
  if not exists (select 1 from profiles where id = auth.uid() and nickname is not null) then
    raise exception 'PROFILE_REQUIRED';
  end if;

  select id into v_id from calendars where invite_code = upper(trim(p_code));
  if v_id is null then raise exception 'INVALID_CODE'; end if;

  insert into calendar_members (calendar_id, user_id) values (v_id, auth.uid())
  on conflict do nothing;
  return v_id;
end $$;

-- 초대코드 재발급 (관리자만, 기존 링크 무효화)
create or replace function public.regenerate_invite_code(p_calendar uuid)
returns text
language plpgsql security definer set search_path = public as $$
declare
  v_code text;
begin
  if not public.is_admin(p_calendar) then raise exception 'FORBIDDEN'; end if;
  loop
    begin
      update calendars set invite_code = gen_invite_code() where id = p_calendar
      returning invite_code into v_code;
      exit;
    exception when unique_violation then
    end;
  end loop;
  return v_code;
end $$;

-- 실행 권한: 로그인 사용자만
revoke execute on all functions in schema public from public, anon;
grant execute on function
  public.create_calendar(text, text),
  public.preview_calendar(text),
  public.join_calendar(text),
  public.regenerate_invite_code(uuid),
  public.is_member(uuid),
  public.is_admin(uuid),
  public.shares_calendar_with(uuid)
to authenticated;

-- ---- 20261013000004_realtime.sql ----
-- =====================================================================
-- 004. Realtime : 캘린더·일정·멤버·프로필 변경을 구독할 수 있게 publication 에 추가
--  (RLS 가 적용되므로 같은 캘린더 멤버에게만 전달됩니다)
-- =====================================================================
do $$ begin
  alter publication supabase_realtime add table public.calendars, public.events, public.calendar_members, public.profiles;
exception when duplicate_object then null;
end $$;

-- ---- 20261013000005_recurring.sql ----
-- 005 : 정기 일정 표시 플래그
-- 반복 규칙(매주/매달 등)을 자동 전개하지 않고, 작성자가 '정기 일정'으로 표시만 한다.
-- 작성자 본인(또는 관리자)만 바꿀 수 있도록 기존 컬럼 단위 update 권한에 포함한다.

alter table public.events add column if not exists is_recurring boolean not null default false;

revoke update on public.events from anon, authenticated;
grant update (title, memo, is_group, is_recurring, start_date, end_date, start_time, end_time)
  on public.events to authenticated;

-- ---- 20261013000006_v3.sql ----
-- =====================================================================
-- 006 : v0.3 — 프로필 사진·최근 색, 반복(요일) 일정, 단체 일정 상세(본문·링크·참여·댓글),
--       계정 삭제 RPC.  모든 구문은 여러 번 실행해도 안전합니다(멱등).
-- =====================================================================

-- ---------------------------------------------------------------------
-- profiles : 최근 사용 색상 (+ 버튼으로 다시 고를 수 있게 저장)
-- ---------------------------------------------------------------------
alter table public.profiles add column if not exists recent_colors text[] not null default '{}';

revoke insert, update, delete on public.profiles from anon, authenticated;
grant update (nickname, color, avatar_url, recent_colors) on public.profiles to authenticated;

-- ---------------------------------------------------------------------
-- events : 반복 요일, 반복 종료일, 링크, 리치 본문
--   · 반복 일정(repeat_weekdays 있음): start_date = 첫 날, end_date = repeat_until, 하루짜리 회차가 요일마다 생긴다
--   · 단체 일정은 반복하지 않는다
-- ---------------------------------------------------------------------
alter table public.events add column if not exists repeat_weekdays smallint[];
alter table public.events add column if not exists repeat_until date;
alter table public.events add column if not exists link_url text;
alter table public.events add column if not exists body_rich jsonb;

alter table public.events drop constraint if exists events_max_span;
alter table public.events add constraint events_max_span check (end_date - start_date <= 400);

alter table public.events drop constraint if exists events_repeat_rule;
alter table public.events add constraint events_repeat_rule check (
  repeat_weekdays is null
  or (
    not is_group
    and repeat_until is not null
    and repeat_until >= start_date
    and cardinality(repeat_weekdays) between 1 and 7
    and repeat_weekdays <@ array[0,1,2,3,4,5,6]::smallint[]
  )
);

alter table public.events drop constraint if exists events_link_len;
alter table public.events add constraint events_link_len check (link_url is null or char_length(link_url) <= 500);

revoke update on public.events from anon, authenticated;
grant update (title, memo, is_group, is_recurring, start_date, end_date, start_time, end_time,
              repeat_weekdays, repeat_until, link_url, body_rich)
  on public.events to authenticated;

-- ---------------------------------------------------------------------
-- event_participants : 단체 일정 참여 멤버
-- event_comments     : 단체 일정 댓글
-- ---------------------------------------------------------------------
create table if not exists public.event_participants (
  event_id   uuid not null references public.events(id) on delete cascade,
  user_id    uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (event_id, user_id)
);

create table if not exists public.event_comments (
  id         uuid primary key default gen_random_uuid(),
  event_id   uuid not null references public.events(id) on delete cascade,
  author_id  uuid not null references public.profiles(id) on delete cascade,
  body       text not null check (char_length(body) between 1 and 500),
  created_at timestamptz not null default now()
);
create index if not exists event_comments_event_idx on public.event_comments (event_id, created_at);

alter table public.event_participants enable row level security;
alter table public.event_comments     enable row level security;

drop policy if exists participants_select on public.event_participants;
create policy participants_select on public.event_participants for select to authenticated
  using (exists (select 1 from public.events e where e.id = event_id and public.is_member(e.calendar_id)));

drop policy if exists participants_insert on public.event_participants;
create policy participants_insert on public.event_participants for insert to authenticated
  with check (
    user_id = auth.uid()
    and exists (select 1 from public.events e where e.id = event_id and e.is_group and public.is_member(e.calendar_id))
  );

drop policy if exists participants_delete on public.event_participants;
create policy participants_delete on public.event_participants for delete to authenticated
  using (user_id = auth.uid());

drop policy if exists comments_select on public.event_comments;
create policy comments_select on public.event_comments for select to authenticated
  using (exists (select 1 from public.events e where e.id = event_id and public.is_member(e.calendar_id)));

drop policy if exists comments_insert on public.event_comments;
create policy comments_insert on public.event_comments for insert to authenticated
  with check (
    author_id = auth.uid()
    and exists (select 1 from public.events e where e.id = event_id and public.is_member(e.calendar_id))
  );

drop policy if exists comments_delete on public.event_comments;
create policy comments_delete on public.event_comments for delete to authenticated
  using (
    author_id = auth.uid()
    or exists (select 1 from public.events e where e.id = event_id and public.is_admin(e.calendar_id))
  );

-- 실시간 반영
do $$ begin
  alter publication supabase_realtime add table public.event_participants, public.event_comments;
exception when duplicate_object then null;
end $$;

-- ---------------------------------------------------------------------
-- 프로필 사진 저장소 (공개 읽기, 본인 폴더(<uid>/...)만 쓰기)
-- ---------------------------------------------------------------------
insert into storage.buckets (id, name, public) values ('avatars', 'avatars', true)
  on conflict (id) do nothing;

drop policy if exists avatars_read on storage.objects;
create policy avatars_read on storage.objects for select to anon, authenticated
  using (bucket_id = 'avatars');

drop policy if exists avatars_insert on storage.objects;
create policy avatars_insert on storage.objects for insert to authenticated
  with check (bucket_id = 'avatars' and (storage.foldername(name))[1] = auth.uid()::text);

drop policy if exists avatars_update on storage.objects;
create policy avatars_update on storage.objects for update to authenticated
  using (bucket_id = 'avatars' and (storage.foldername(name))[1] = auth.uid()::text);

drop policy if exists avatars_delete on storage.objects;
create policy avatars_delete on storage.objects for delete to authenticated
  using (bucket_id = 'avatars' and (storage.foldername(name))[1] = auth.uid()::text);

-- ---------------------------------------------------------------------
-- 계정 삭제
--  1) 내가 유일한 관리자인 캘린더: 다른 멤버가 있으면 가장 먼저 들어온 사람에게 관리자·소유권 넘김, 없으면 캘린더 삭제
--  2) 내 멤버십 삭제 → 그 캘린더에서 내가 쓴 일정·댓글·참여 기록도 함께 삭제(FK cascade)
--  3) auth 사용자 삭제 → 프로필 삭제
--  프로필 사진 파일은 클라이언트가 Storage API 로 먼저 지운다(SQL 로 storage 를 직접 지우는 것은 막혀 있음)
-- ---------------------------------------------------------------------
create or replace function public.delete_my_account() returns void
language plpgsql security definer set search_path = public, auth as $$
declare
  uid uuid := auth.uid();
  c record;
  nxt uuid;
begin
  if uid is null then
    raise exception 'NOT_AUTHENTICATED';
  end if;

  for c in select calendar_id from public.calendar_members where user_id = uid loop
    select user_id into nxt
      from public.calendar_members
     where calendar_id = c.calendar_id and user_id <> uid
     order by (role = 'admin') desc, joined_at
     limit 1;

    if nxt is null then
      -- 혼자 남은 캘린더는 함께 사라진다
      delete from public.calendars where id = c.calendar_id;
    else
      if not exists (
        select 1 from public.calendar_members
         where calendar_id = c.calendar_id and role = 'admin' and user_id <> uid
      ) then
        update public.calendar_members set role = 'admin'
         where calendar_id = c.calendar_id and user_id = nxt;
      end if;
      update public.calendars set owner_id = nxt
       where id = c.calendar_id and owner_id = uid;
    end if;
  end loop;

  delete from public.calendar_members where user_id = uid;
  delete from auth.users where id = uid;
end $$;

revoke execute on function public.delete_my_account() from public, anon;
grant execute on function public.delete_my_account() to authenticated;

-- ---- 20261013000007_notices_admin_participants.sql ----
-- =====================================================================
-- 007. v0.4 : 캘린더 공지사항 · 관리자가 단체 일정 참여 멤버를 지정
-- 여러 번 실행해도 안전합니다(멱등).
-- =====================================================================

-- 1) 공지사항: 모든 멤버가 읽고, 관리자만 작성·수정·삭제
create table if not exists public.announcements (
  id          uuid primary key default gen_random_uuid(),
  calendar_id uuid not null references public.calendars(id) on delete cascade,
  author_id   uuid not null references public.profiles(id) on delete cascade,
  title       text not null check (char_length(title) between 1 and 60),
  body        text not null default '' check (char_length(body) <= 2000),
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);
create index if not exists announcements_calendar_idx on public.announcements (calendar_id, created_at desc);

drop trigger if exists announcements_touch on public.announcements;
create trigger announcements_touch before update on public.announcements
  for each row execute function public.touch_updated_at();

alter table public.announcements enable row level security;

drop policy if exists announcements_select on public.announcements;
create policy announcements_select on public.announcements for select to authenticated
  using (public.is_member(calendar_id));

drop policy if exists announcements_insert on public.announcements;
create policy announcements_insert on public.announcements for insert to authenticated
  with check (author_id = auth.uid() and public.is_admin(calendar_id));

drop policy if exists announcements_update on public.announcements;
create policy announcements_update on public.announcements for update to authenticated
  using (public.is_admin(calendar_id))
  with check (public.is_admin(calendar_id));

drop policy if exists announcements_delete on public.announcements;
create policy announcements_delete on public.announcements for delete to authenticated
  using (public.is_admin(calendar_id));

grant select, insert, update, delete on public.announcements to authenticated;

do $$ begin
  alter publication supabase_realtime add table public.announcements;
exception when duplicate_object then null;
end $$;

-- 2) 단체 일정 참여 멤버: 관리자는 같은 캘린더의 멤버를 지정·해제할 수 있다 (기존 '본인 참여' 규칙은 그대로)
drop policy if exists participants_admin_insert on public.event_participants;
create policy participants_admin_insert on public.event_participants for insert to authenticated
  with check (
    exists (
      select 1 from public.events e
      where e.id = event_id and e.is_group and public.is_admin(e.calendar_id)
    )
    and exists (
      select 1 from public.events e
      join public.calendar_members m on m.calendar_id = e.calendar_id
      where e.id = event_id and m.user_id = event_participants.user_id
    )
  );

drop policy if exists participants_admin_delete on public.event_participants;
create policy participants_admin_delete on public.event_participants for delete to authenticated
  using (exists (select 1 from public.events e where e.id = event_id and public.is_admin(e.calendar_id)));
