// 캘린더 공지사항: 모든 멤버가 읽고, 관리자만 작성·수정·삭제 (실시간 반영)
import { useEffect, useState, type FormEvent } from 'react';
import type { Announcement, Profile } from '@/types';
import { fmtMD } from '@/lib/dates';
import { errorMessage, supabase } from '@/lib/supabase';
import { Sheet } from '@/ui/Sheet';
import { Icon } from '@/ui/Icon';
import { useFeedback } from '@/ui/Feedback';

const uniq = () => Math.random().toString(36).slice(2, 8);

export function useAnnouncements(calendarId: string) {
  const [rows, setRows] = useState<Announcement[] | null>(null);

  useEffect(() => {
    let alive = true;
    const load = async () => {
      const { data, error } = await supabase
        .from('announcements')
        .select('id, calendar_id, author_id, title, body, created_at, updated_at, author:profiles(id, nickname, color, avatar_url)')
        .eq('calendar_id', calendarId)
        .order('created_at', { ascending: false })
        .limit(100);
      if (alive && !error) setRows((data ?? []) as unknown as Announcement[]);
    };
    load();
    const ch = supabase
      .channel(`notice:${calendarId}:${uniq()}`)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'announcements', filter: `calendar_id=eq.${calendarId}` }, () => load())
      // 삭제 알림은 PK 만 오므로 한 번 더 불러온다
      .on('postgres_changes', { event: 'DELETE', schema: 'public', table: 'announcements' }, () => load())
      .subscribe();
    return () => {
      alive = false;
      supabase.removeChannel(ch);
    };
  }, [calendarId]);

  return rows;
}

export function AnnouncementsPanel({ calendarId, myId, isAdmin, profiles }: { calendarId: string; myId: string; isAdmin: boolean; profiles: Map<string, Profile> }) {
  const rows = useAnnouncements(calendarId);
  const { toast, confirm } = useFeedback();
  const [openId, setOpenId] = useState<string | null>(null);
  const [editor, setEditor] = useState<{ item: Announcement | null } | null>(null);

  const remove = async (a: Announcement) => {
    const ok = await confirm({ title: '공지를 삭제할까요?', message: `「${a.title}」`, confirmText: '삭제', danger: true });
    if (!ok) return;
    const { error } = await supabase.from('announcements').delete().eq('id', a.id);
    if (error) toast(errorMessage(error), 'error');
    else toast('공지를 삭제했어요.', 'success');
  };

  return (
    <section className="panel notice-panel" aria-label="공지사항">
      <header className="panel-head">
        <h2>공지사항</h2>
        {isAdmin && (
          <button type="button" className="btn btn-ghost btn-small" onClick={() => setEditor({ item: null })}>
            <Icon name="plus" size={14} /> 작성
          </button>
        )}
      </header>
      {rows === null ? (
        <p className="muted small">불러오는 중…</p>
      ) : rows.length === 0 ? (
        <p className="empty small">등록된 공지사항이 없어요.</p>
      ) : (
        <ul className="notice-list">
          {rows.map((a) => {
            const open = openId === a.id;
            const author = profiles.get(a.author_id)?.nickname ?? a.author?.nickname ?? '(알 수 없음)';
            return (
              <li key={a.id} className={`notice-item ${open ? 'open' : ''}`}>
                <button type="button" className="notice-head" aria-expanded={open} onClick={() => setOpenId(open ? null : a.id)}>
                  <span className="notice-title">{a.title}</span>
                  <span className="notice-meta muted small">
                    {fmtMD(a.created_at.slice(0, 10))} · {author}
                  </span>
                </button>
                {open && (
                  <div className="notice-body">
                    {a.body ? <p>{a.body}</p> : <p className="muted small">내용이 없어요.</p>}
                    {isAdmin && (
                      <div className="notice-actions">
                        <button type="button" className="btn btn-ghost btn-small" onClick={() => setEditor({ item: a })}>
                          수정
                        </button>
                        <button type="button" className="btn btn-ghost btn-small danger-text" onClick={() => remove(a)}>
                          삭제
                        </button>
                      </div>
                    )}
                  </div>
                )}
              </li>
            );
          })}
        </ul>
      )}
      {editor && (
        <NoticeEditor
          key={editor.item?.id ?? 'new'}
          calendarId={calendarId}
          myId={myId}
          item={editor.item}
          onClose={() => setEditor(null)}
        />
      )}
    </section>
  );
}

function NoticeEditor({ calendarId, myId, item, onClose }: { calendarId: string; myId: string; item: Announcement | null; onClose: () => void }) {
  const { toast } = useFeedback();
  const [title, setTitle] = useState(item?.title ?? '');
  const [body, setBody] = useState(item?.body ?? '');
  const [busy, setBusy] = useState(false);

  const save = async (e?: FormEvent) => {
    e?.preventDefault();
    if (!title.trim() || busy) return;
    setBusy(true);
    const payload = { title: title.trim(), body: body.trim() };
    const { error } = item
      ? await supabase.from('announcements').update(payload).eq('id', item.id)
      : await supabase.from('announcements').insert({ ...payload, calendar_id: calendarId, author_id: myId });
    setBusy(false);
    if (error) return toast(errorMessage(error), 'error');
    toast(item ? '공지를 고쳤어요.' : '공지를 올렸어요.', 'success');
    onClose();
  };

  return (
    <Sheet
      open
      onClose={onClose}
      title={item ? '공지 수정' : '공지 작성'}
      footer={
        <>
          <button type="button" className="btn btn-ghost" onClick={onClose}>
            취소
          </button>
          <button type="submit" form="notice-form" className="btn btn-primary" disabled={!title.trim() || busy}>
            {busy ? '저장 중…' : '저장'}
          </button>
        </>
      }
    >
      <form id="notice-form" className="stack" onSubmit={save}>
        <label className="field">
          <span className="field-label">제목</span>
          <input className="input" value={title} maxLength={60} onChange={(e) => setTitle(e.target.value)} autoFocus />
        </label>
        <label className="field">
          <span className="field-label">내용 (선택)</span>
          <textarea className="input" rows={6} maxLength={2000} value={body} onChange={(e) => setBody(e.target.value)} />
        </label>
        <p className="muted small">공지는 이 캘린더의 모든 멤버에게 보여요. 관리자만 작성·수정·삭제할 수 있어요.</p>
      </form>
    </Sheet>
  );
}
