import { useEffect, useMemo, useState, type FormEvent } from 'react';
import type { CalendarEvent, EventInput, Profile } from '@/types';
import { addDays, diffDays, fmtMD, minToTime, toMin, todayYmd, WEEKDAYS } from '@/lib/dates';
import { errorMessage } from '@/lib/supabase';
import { findUrls, normalizeUrl } from '@/lib/links';
import { Sheet } from '@/ui/Sheet';
import { Segmented } from '@/ui/controls';
import { useFeedback } from '@/ui/Feedback';
import { RangePicker } from './RangePicker';
import { findConflicts, loadParticipantIds, syncParticipants, type Conflict } from './groupAssign';

export type FormTarget = { date?: string; event?: CalendarEvent; group?: boolean };

export type CalOption = { id: string; name: string };

type Props = {
  target: FormTarget | null;
  calendars: CalOption[]; // 추가할 캘린더 후보 (한 개면 선택 칸을 숨긴다)
  defaultCalendarId: string;
  adminOf: (calendarId: string) => boolean;
  members?: Profile[]; // 단체 일정 참여 멤버 후보 (캘린더 화면에서만 넘긴다)
  onClose: () => void;
  onCreate: (input: EventInput, calendarIds: string[]) => Promise<CalendarEvent[]>;
  onUpdate: (id: string, input: EventInput) => Promise<void>;
};

// 30분 단위 시간 목록
const STARTS = Array.from({ length: 48 }, (_, i) => minToTime(i * 30)); // 00:00 ~ 23:30
const ENDS = Array.from({ length: 48 }, (_, i) => minToTime((i + 1) * 30)); // 00:30 ~ 24:00
const MAX_SPAN = 62; // 날짜 범위 최대 길이(일)
const MAX_REPEAT_SPAN = 400; // 요일 반복을 넣을 때의 최대 기간(일)
const REPEAT_DEFAULT_DAYS = 90; // 요일을 처음 고를 때 종료일이 시작일과 같으면 채우는 기간

const snap = (t: string | null, fallback: string) => {
  if (!t) return fallback;
  const m = Math.round(toMin(t) / 30) * 30;
  return minToTime(Math.min(m, 1440));
};

export function EventFormSheet({ target, calendars, defaultCalendarId, adminOf, members, onClose, onCreate, onUpdate }: Props) {
  const { toast } = useFeedback();
  const editing = target?.event;
  const baseDate = editing?.occ ?? editing?.start_date ?? target?.date ?? todayYmd();

  const [pickedCals, setPickedCals] = useState<string[]>(() => [editing?.calendar_id ?? defaultCalendarId]);
  const groupOk = (ids: string[]) => ids.length > 0 && ids.every((id) => adminOf(id));
  const [kind, setKind] = useState<'personal' | 'group'>(editing ? (editing.is_group ? 'group' : 'personal') : target?.group ? 'group' : 'personal');

  const [title, setTitle] = useState(editing?.title ?? '');
  const [text, setText] = useState(editing?.memo ?? ''); // 개인: 메모 · 단체: 설명(본문)
  const [start, setStart] = useState(baseDate);
  const [end, setEnd] = useState(editing ? (editing.repeat_weekdays ? (editing.repeat_until ?? editing.end_date) : editing.end_date) : baseDate);
  const [weekdays, setWeekdays] = useState<number[]>(editing?.repeat_weekdays ?? []);
  const [allDay, setAllDay] = useState(editing ? !editing.start_time : true);
  const [startTime, setStartTime] = useState(snap(editing?.start_time ?? null, '19:00'));
  const [endTime, setEndTime] = useState(snap(editing?.end_time ?? null, '21:00'));
  // 단체 일정 참여 멤버
  const [participants, setParticipants] = useState<string[]>([]);
  const [initialParticipants, setInitialParticipants] = useState<string[]>([]);
  const [conflicts, setConflicts] = useState<Conflict[]>([]);
  const [busy, setBusy] = useState(false);
  const [tried, setTried] = useState(false);

  const isGroup = kind === 'group';
  const weekly = !isGroup && weekdays.length > 0;
  const groupOkNow = groupOk(pickedCals);
  const single = pickedCals.length === 1 ? pickedCals[0] : null;
  const canAssign = isGroup && !!single && adminOf(single) && !!members?.length;
  const maxSpan = weekly ? MAX_REPEAT_SPAN : MAX_SPAN;
  const url = useMemo(() => (isGroup && text.trim() ? normalizeUrl(findUrls(text)[0] ?? '') : null), [isGroup, text]);
  const nameOf = (id: string) => members?.find((m) => m.id === id)?.nickname ?? '(알 수 없음)';

  // 수정 중인 단체 일정이면 지금 지정된 참여 멤버를 불러온다
  useEffect(() => {
    if (!editing?.is_group) return;
    loadParticipantIds(editing.id)
      .then((ids) => {
        setParticipants(ids);
        setInitialParticipants(ids);
      })
      .catch(() => undefined);
  }, [editing?.id, editing?.is_group]);

  const errors = useMemo(() => {
    const e: string[] = [];
    if (!title.trim()) e.push('제목을 입력해 주세요.');
    if (!pickedCals.length) e.push('캘린더를 하나 이상 고르세요.');
    if (isGroup && !groupOkNow) e.push('전체(단체) 일정은 선택한 캘린더의 관리자만 만들 수 있어요.');
    if (!start || !end) e.push('날짜를 골라 주세요.');
    else if (end < start) e.push('종료 날짜가 시작 날짜보다 빠를 수 없어요.');
    else if (diffDays(start, end) > maxSpan) e.push(`기간은 최대 ${maxSpan + 1}일까지 골라요.`);
    if (!allDay && (weekly || start === end) && toMin(endTime) <= toMin(startTime)) e.push('종료 시간이 시작 시간보다 늦어야 해요.');
    return e;
  }, [title, pickedCals, isGroup, groupOkNow, start, end, maxSpan, allDay, weekly, startTime, endTime]);

  const toggleCal = (id: string) =>
    setPickedCals((list) => {
      const next = list.includes(id) ? list.filter((x) => x !== id) : [...list, id];
      if (!groupOk(next) && kind === 'group') setKind('personal');
      return next;
    });

  const toggleWeekday = (d: number) =>
    setWeekdays((list) => {
      const next = list.includes(d) ? list.filter((x) => x !== d) : [...list, d].sort((a, b) => a - b);
      // 요일을 처음 고르고 기간이 하루뿐이면 기본 기간을 채운다 (달력에서 종료 날짜를 바꿀 수 있다)
      if (next.length && !list.length && end === start) setEnd(addDays(start, REPEAT_DEFAULT_DAYS));
      return next;
    });

  const toggleAllDay = () => setAllDay((v) => !v);

  const chooseKind = (k: 'personal' | 'group') => {
    setKind(k);
    if (k === 'group') setWeekdays([]);
    if (k === 'personal') setParticipants([]);
  };

  const toggleParticipant = (id: string) => {
    setConflicts([]);
    setParticipants((list) => (list.includes(id) ? list.filter((x) => x !== id) : [...list, id]));
  };

  const submit = async (e?: FormEvent) => {
    e?.preventDefault();
    setTried(true);
    if (errors.length || busy) return;

    const input: EventInput = {
      title: title.trim(),
      memo: text.trim() || null,
      is_group: isGroup,
      is_recurring: weekly,
      start_date: start,
      end_date: end,
      start_time: allDay ? null : startTime,
      end_time: allDay ? null : endTime,
      repeat_weekdays: weekly ? [...weekdays].sort((a, b) => a - b) : null,
      repeat_until: weekly ? end : null,
      link_url: url,
    };

    setBusy(true);
    try {
      // 참여 멤버를 고른 단체 일정은 저장 전에 개인 일정과 겹치는지 확인한다
      if (canAssign && participants.length && single) {
        const found = await findConflicts(
          single,
          participants,
          { start_date: start, end_date: end, start_time: allDay ? null : startTime, end_time: allDay ? null : endTime },
          nameOf,
        );
        if (found.length) {
          setConflicts(found);
          return;
        }
      }

      if (editing) {
        await onUpdate(editing.id, input);
        if (canAssign) await syncParticipants(editing.id, participants, initialParticipants);
      } else {
        const rows = await onCreate(input, pickedCals);
        if (canAssign && participants.length && rows[0]) await syncParticipants(rows[0].id, participants, []);
      }
      toast(editing ? '일정을 수정했어요.' : '일정을 추가했어요.', 'success');
      onClose();
    } catch (err) {
      toast(errorMessage(err), 'error');
    } finally {
      setBusy(false);
    }
  };

  return (
    <Sheet
      open={target !== null}
      onClose={onClose}
      title={editing ? '일정 수정' : '일정 추가'}
      footer={
        <>
          <button type="button" className="btn btn-ghost" onClick={onClose}>
            취소
          </button>
          <button type="button" className="btn btn-primary" onClick={() => submit()} disabled={busy}>
            {busy ? '저장 중…' : '저장'}
          </button>
        </>
      }
    >
      <form className="stack" onSubmit={submit}>
        <div className="field">
          <span className="field-label">종류</span>
          <Segmented
            ariaLabel="일정 종류"
            value={kind}
            onChange={chooseKind}
            options={[
              { value: 'personal', label: '개인 일정' },
              { value: 'group', label: `전체 일정${groupOkNow ? '' : ' (관리자)'}` },
            ]}
          />
          {kind === 'group' && !groupOkNow && <p className="muted small">전체 일정은 관리자만 만들 수 있어요. 개인 일정으로 저장하세요.</p>}
        </div>

        {calendars.length > 1 && !editing && (
          <div className="field">
            <span className="field-label">추가할 캘린더</span>
            <div className="chip-wrap">
              {calendars.map((c) => {
                const on = pickedCals.includes(c.id);
                return (
                  <button key={c.id} type="button" className={`chip-pick ${on ? 'on' : ''}`} aria-pressed={on} onClick={() => toggleCal(c.id)}>
                    {c.name}
                  </button>
                );
              })}
            </div>
            <p className="muted small">같은 일정을 고른 캘린더마다 하나씩 추가돼요.</p>
          </div>
        )}

        <label className="field">
          <span className="field-label">제목</span>
          <input className="input" value={title} maxLength={40} placeholder="예: 스터디, 알바, 여행" onChange={(e) => setTitle(e.target.value)} autoFocus={!editing} />
        </label>

        <div className="field">
          <span className="field-label">날짜 (달력에서 시작·종료 날짜 선택)</span>
          <RangePicker
            start={start}
            end={end}
            maxSpan={maxSpan}
            onChange={(s, e) => {
              setStart(s);
              setEnd(e);
              setConflicts([]);
            }}
          />
        </div>

        {!isGroup && (
          <div className="field">
            <span className="field-label">요일 반복 (선택)</span>
            <div className="weekday-row" role="group" aria-label="반복 요일">
              {WEEKDAYS.map((w, i) => {
                const on = weekdays.includes(i);
                return (
                  <button key={w} type="button" className={`wd-btn ${on ? 'on' : ''} ${i === 0 ? 'sun' : i === 6 ? 'sat' : ''}`} aria-pressed={on} onClick={() => toggleWeekday(i)}>
                    {w}
                  </button>
                );
              })}
            </div>
            <p className="muted small">{weekly ? `선택한 기간 안에서 ${fmtMD(start)} 이후 매주 그 요일마다 반복돼요.` : '요일을 누르면 선택한 기간 안에서 매주 반복돼요.'}</p>
          </div>
        )}

        <div className="field">
          <span className="field-label">시간</span>
          <div className="time-row">
            <select className="input" value={startTime} disabled={allDay} aria-label="시작 시간" onChange={(e) => setStartTime(e.target.value)}>
              {STARTS.map((t) => (
                <option key={t}>{t}</option>
              ))}
            </select>
            <span className="muted">~</span>
            <select className="input" value={endTime} disabled={allDay} aria-label="종료 시간" onChange={(e) => setEndTime(e.target.value)}>
              {ENDS.map((t) => (
                <option key={t} disabled={(weekly || start === end) && toMin(t) <= toMin(startTime)}>
                  {t}
                </option>
              ))}
            </select>
            <button type="button" className={`chip-pick allday-chip ${allDay ? 'on' : ''}`} aria-pressed={allDay} onClick={toggleAllDay}>
              하루종일
            </button>
          </div>
          {allDay && <p className="muted small">하루종일 일정이에요. 시간을 정하려면 ‘하루종일’을 끄세요.</p>}
        </div>

        {isGroup ? (
          <>
            <label className="field">
              <span className="field-label">설명 (선택)</span>
              <textarea
                className="input"
                rows={6}
                maxLength={2000}
                value={text}
                placeholder="모임 내용을 적어 주세요. 유튜브·X 같은 외부 링크를 넣으면 본문 아래에 미리보기가 떠요."
                onChange={(e) => setText(e.target.value)}
              />
            </label>
            {canAssign && (
              <div className="field">
                <span className="field-label">참여 멤버 지정 (선택)</span>
                <div className="chip-wrap" role="group" aria-label="참여 멤버">
                  {members!.map((m) => {
                    const on = participants.includes(m.id);
                    return (
                      <button key={m.id} type="button" className={`chip-pick ${on ? 'on' : ''}`} aria-pressed={on} onClick={() => toggleParticipant(m.id)}>
                        {m.nickname ?? '(알 수 없음)'}
                      </button>
                    );
                  })}
                </div>
                <p className="muted small">지정한 멤버의 일정에 이 전체 일정이 함께 보여요. 그 시간에 개인 일정이 있으면 저장할 수 없어요.</p>
              </div>
            )}
          </>
        ) : (
          <label className="field">
            <span className="field-label">메모 (선택)</span>
            <textarea className="input" rows={3} maxLength={500} value={text} onChange={(e) => setText(e.target.value)} />
          </label>
        )}

        {conflicts.length > 0 && (
          <div className="form-errors conflict-box" role="alert">
            <b>이 시간에 개인 일정이 있는 멤버가 있어요. 참여 멤버에서 빼거나 시간을 바꿔 주세요.</b>
            <ul>
              {conflicts.map((c, i) => (
                <li key={`${c.userId}-${c.date}-${i}`}>
                  {c.title} · {fmtMD(c.date)} {c.time}
                </li>
              ))}
            </ul>
          </div>
        )}

        {tried && errors.length > 0 && (
          <ul className="form-errors" role="alert">
            {errors.map((m) => (
              <li key={m}>{m}</li>
            ))}
          </ul>
        )}
        <button type="submit" hidden />
      </form>
    </Sheet>
  );
}
