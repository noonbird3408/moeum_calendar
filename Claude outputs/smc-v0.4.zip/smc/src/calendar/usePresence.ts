// 현재 이 캘린더에 접속 중인 멤버 (Supabase Realtime Presence, 서버 없이 채널로만 동작)
import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';

const uniq = () => Math.random().toString(36).slice(2, 8);

export function usePresence(calendarId: string, userId: string) {
  const [online, setOnline] = useState<Set<string>>(() => new Set());

  useEffect(() => {
    // key 를 user id 로 두면 presenceState() 의 키가 곧 접속 중인 사용자 id 가 된다
    const ch = supabase.channel(`presence:${calendarId}:${uniq()}`, { config: { presence: { key: userId } } });

    ch.on('presence', { event: 'sync' }, () => {
      setOnline(new Set(Object.keys(ch.presenceState())));
    }).subscribe(async (status) => {
      if (status === 'SUBSCRIBED') await ch.track({ user_id: userId, at: Date.now() });
    });

    return () => {
      supabase.removeChannel(ch);
    };
  }, [calendarId, userId]);

  return online;
}
