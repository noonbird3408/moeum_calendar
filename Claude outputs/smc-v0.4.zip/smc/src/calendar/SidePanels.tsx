// 캘린더 옆 패널: 멤버 목록(접속 상태)
import type { Member } from '@/types';
import { Avatar } from '@/ui/Avatar';
import { Icon } from '@/ui/Icon';

const ONLINE = '#16a34a';
const OFFLINE = '#9aa1ac';

export function MembersPanel({
  members,
  myId,
  online,
  isAdmin,
  onManage,
}: {
  members: Member[];
  myId: string;
  online: Set<string>;
  isAdmin: boolean;
  onManage: () => void;
}) {
  // 접속 중인 사람을 위에, 그다음 관리자, 그다음 이름순
  const sorted = [...members].sort(
    (a, b) =>
      Number(online.has(b.user_id)) - Number(online.has(a.user_id)) ||
      Number(b.role === 'admin') - Number(a.role === 'admin') ||
      (a.profile?.nickname ?? '').localeCompare(b.profile?.nickname ?? ''),
  );
  const onlineCount = members.filter((m) => online.has(m.user_id)).length;

  return (
    <section className="panel members-panel" aria-label="멤버 목록">
      <header className="panel-head">
        <h2>멤버 목록</h2>
        <span className="online-count">
          <span className="online-dot on" aria-hidden="true" /> 접속 {onlineCount}명 <span className="muted">/ 전체 {members.length}명</span>
        </span>
      </header>
      <ul className="member-mini">
        {sorted.map((m) => {
          const isOn = online.has(m.user_id);
          return (
            <li key={m.user_id} className={`mini-row ${m.user_id === myId ? 'is-me' : ''}`}>
              <span className="online-dot" style={{ background: isOn ? ONLINE : OFFLINE }} role="img" aria-label={isOn ? '접속 중' : '접속 안 함'} />
              <Avatar profile={m.profile} size={24} />
              <span className="mini-name">
                {m.profile?.nickname ?? '(알 수 없음)'}
                {m.user_id === myId && <span className="muted small"> (나)</span>}
              </span>
              {m.role === 'admin' && <span className="badge badge-admin">관리자</span>}
            </li>
          );
        })}
      </ul>
      {isAdmin && (
        <button type="button" className="btn btn-ghost btn-small btn-block" onClick={onManage}>
          <Icon name="users" size={16} /> 멤버 관리
        </button>
      )}
    </section>
  );
}
