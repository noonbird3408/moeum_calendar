// 내 일정 (이 캘린더에서 내가 등록한 개인 일정, 오늘 이후) — 패널 요약 + '전체 보기' 시트(추가·수정·삭제·일괄 삭제)
import { useEffect, useMemo, useState } from 'react';
import type { CalendarEvent } from '@/types';
import { todayYmd } from '@/lib/dates';
import { errorMessage, supabase } from '@/lib/supabase';
import { Sheet } from '@/ui/Sheet';
import { Icon } from '@/ui/Icon';
import { useFeedback } from '@/ui/Feedback';
import { scheduleText } from './eventUtils';

const PREVIEW = 3; // 패널에는 3개까지 보이고, 4개 이상이면 '…' 로 펼친다

/** 내 개인 일정 목록: 정기 일정을 위에, 나머지는 날짜순. 지난 일정과 단체 일정은 빼고 읽는다. */
export function useMyEvents(calendarId: string, userId: string, refreshKey: unknown) {
  const [rows, setRows] = useState<CalendarEvent[] | null>(null);

  useEffect(() => {
    let alive = true;
    supabase
      .from('events')
      .select('*')
      .eq('calendar_id', calendarId)
      .eq('author_id', userId)
      .eq('is_group', false)
      .gte('end_date', todayYmd())
      .order('start_date')
      .limit(300)
      .then(({ data }) => {
        if (!alive) return;
        const list = (data ?? []) as CalendarEvent[];
        list.sort((a, b) => Number(!!b.repeat_weekdays) - Number(!!a.repeat_weekdays) || a.start_date.localeCompare(b.start_date) || (a.start_time ?? '').localeCompare(b.start_time ?? ''));
        setRows(list);
      });
    return () => {
      alive = false;
    };
  }, [calendarId, userId, refreshKey]);

  return rows;
}

/* ------------------------------------------------------------------ */
/* 패널 요약                                                           */
/* ------------------------------------------------------------------ */
export function MyEventsPanel({
  rows,
  onOpen,
  onOpenAll,
}: {
  rows: CalendarEvent[] | null;
  onOpen: (e: CalendarEvent) => void;
  onOpenAll: () => void;
}) {
  const shown = rows && rows.length > PREVIEW ? rows.slice(0, PREVIEW) : rows ?? [];
  const more = rows ? rows.length - shown.length : 0;

  return (
    <section className="panel my-events" aria-label="내 일정">
      <header className="panel-head">
        <h2>내 일정</h2>
        <button type="button" className="btn btn-ghost btn-small" onClick={onOpenAll}>
          전체 보기
        </button>
      </header>
      {rows === null ? (
        <p className="muted small">불러오는 중…</p>
      ) : rows.length === 0 ? (
        <p className="empty small">이 캘린더에 내가 등록한 예정 일정이 없어요.</p>
      ) : (
        <ul className="my-list">
          {shown.map((e) => (
            <li key={e.id}>
              <button type="button" className={`my-item ${e.repeat_weekdays ? 'is-recurring' : ''}`} onClick={() => onOpen(e)}>
                <span className="my-title">
                  {e.repeat_weekdays && <span className="badge badge-recur">↻ 정기</span>} {e.title}
                </span>
                <span className="my-sub">{scheduleText(e)}</span>
              </button>
            </li>
          ))}
          {more > 0 && (
            <li>
              <button type="button" className="my-more" onClick={onOpenAll} aria-label={`일정 ${more}개 더 보기`}>
                …
              </button>
            </li>
          )}
        </ul>
      )}
    </section>
  );
}

/* ------------------------------------------------------------------ */
/* 전체 보기 시트: 추가 · 수정 · 삭제 · 일괄 선택                          */
/* ------------------------------------------------------------------ */
export function MyEventsSheet({
  open,
  rows,
  onClose,
  onOpen,
  onEdit,
  onAdd,
}: {
  open: boolean;
  rows: CalendarEvent[] | null;
  onClose: () => void;
  onOpen: (e: CalendarEvent) => void;
  onEdit: (e: CalendarEvent) => void;
  onAdd: () => void;
}) {
  const { toast, confirm } = useFeedback();
  const [picked, setPicked] = useState<Set<string>>(() => new Set());
  const [busy, setBusy] = useState(false);
  const all = rows ?? [];
  const allOn = all.length > 0 && picked.size === all.length;

  // 목록이 바뀌면 사라진 항목은 선택에서 뺀다
  const liveIds = useMemo(() => new Set(all.map((e) => e.id)), [all]);
  const selected = [...picked].filter((id) => liveIds.has(id));

  const toggle = (id: string) =>
    setPicked((s) => {
      const n = new Set(s);
      if (n.has(id)) n.delete(id);
      else n.add(id);
      return n;
    });

  const toggleAll = () => setPicked(allOn ? new Set() : new Set(all.map((e) => e.id)));

  const removeSelected = async () => {
    if (!selected.length) return;
    const ok = await confirm({
      title: `${selected.length}개 일정을 삭제할까요?`,
      message: '삭제하면 되돌릴 수 없어요. 정기 일정은 반복 전체가 함께 지워져요.',
      confirmText: '삭제',
      danger: true,
    });
    if (!ok) return;
    setBusy(true);
    try {
      const { data, error } = await supabase.from('events').delete().in('id', selected).select('id');
      if (error) throw error;
      toast(`${data?.length ?? 0}개 일정을 삭제했어요.`, 'success');
      setPicked(new Set());
    } catch (err) {
      toast(errorMessage(err), 'error');
    } finally {
      setBusy(false);
    }
  };

  const recurring = all.filter((e) => e.repeat_weekdays);
  const plain = all.filter((e) => !e.repeat_weekdays);

  const row = (e: CalendarEvent) => (
    <li key={e.id} className={`mine-row ${picked.has(e.id) ? 'on' : ''}`}>
      <input
        type="checkbox"
        className="mine-check"
        checked={picked.has(e.id)}
        onChange={() => toggle(e.id)}
        aria-label={`${e.title} 선택`}
      />
      <button type="button" className="mine-main" onClick={() => onOpen(e)}>
        <span className="my-title">
          {e.repeat_weekdays && <span className="badge badge-recur">↻ 정기</span>} {e.title}
        </span>
        <span className="my-sub">{scheduleText(e)}</span>
      </button>
      <button type="button" className="btn btn-ghost btn-small" onClick={() => onEdit(e)} aria-label={`${e.title} 수정`}>
        <Icon name="edit" size={16} /> 수정
      </button>
    </li>
  );

  return (
    <Sheet
      open={open}
      onClose={onClose}
      title="내 일정 전체"
      footer={
        <>
          <button type="button" className="btn btn-ghost danger-text" onClick={removeSelected} disabled={!selected.length || busy}>
            <Icon name="trash" size={18} /> 선택 삭제{selected.length ? ` (${selected.length})` : ''}
          </button>
          <button type="button" className="btn btn-primary" onClick={onAdd}>
            <Icon name="plus" size={18} /> 일정 추가
          </button>
        </>
      }
    >
      {rows === null ? (
        <p className="muted small">불러오는 중…</p>
      ) : all.length === 0 ? (
        <p className="empty">예정된 내 일정이 없어요. ‘일정 추가’로 만들어 보세요.</p>
      ) : (
        <>
          <div className="mine-toolbar">
            <label className="mine-all">
              <input type="checkbox" checked={allOn} onChange={toggleAll} /> 전체 선택
            </label>
            <span className="muted small">{selected.length ? `${selected.length}개 선택` : `${all.length}개`}</span>
          </div>
          {recurring.length > 0 && (
            <section className="day-section">
              <h3>정기 일정</h3>
              <ul className="mine-list">{recurring.map(row)}</ul>
            </section>
          )}
          {plain.length > 0 && (
            <section className="day-section">
              <h3>예정 일정</h3>
              <ul className="mine-list">{plain.map(row)}</ul>
            </section>
          )}
        </>
      )}
    </Sheet>
  );
}
