import { ProfileForm } from './ProfileForm';
import { useAuth } from './AuthProvider';

export function OnboardingPage() {
  const { email, signOut } = useAuth();
  return (
    <main className="center-page">
      <div className="login-card wide">
        <h1>프로필 설정</h1>
        <p className="muted">캘린더에서 다른 멤버에게 보일 이름과 색을 정해 주세요. 나중에 설정에서 바꿀 수 있어요.</p>
        <ProfileForm submitText="시작하기" />
        <p className="fine">
          {email} 로 로그인됨 ·{' '}
          <button type="button" className="link-btn" onClick={signOut}>
            다른 계정으로
          </button>
        </p>
      </div>
    </main>
  );
}
