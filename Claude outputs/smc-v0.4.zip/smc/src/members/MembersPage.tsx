import { useEffect, useState } from 'react';
import type { Member } from '@/types';
import { useAuth } from '@/auth/AuthProvider';
import { GROUP_COLORS, GRAY, textOn } from '@/lib/colors';
import { errorMessage } from '@/lib/supabase';
import { Link, useRouter } from '@/lib/router';
import { useCalendarMeta } from '@/calendar/useCalendarData';
import { ShareSheet, inviteUrl } from '@/calendars/ShareSheet';
import { ColorPicker, Splash } from '@/ui/controls';
import { Icon } from '@/ui/Icon';
import { useFeedback } from '@/ui/Feedback';

export function MembersPage({ calendarId }: { calendarId: string }) {
  const { userId } = useAuth();
  const { navigate } = useRouter();
  const { toast, confirm } = useFeedback();
  const meta = useCalendarMeta(calendarId, userId, () => {
    toast('이 캘린더의 멤버가 아니게 되었어요.', 'info');
    navigate('/', { replace: true });
  });
  const [shareOpen, setShareOpen] = useState(false);
  const [name, setName] = useState('');
  const [busy, setBusy] = useState<string | null>(null);

  useEffect(() => {
    if (meta.calendar) setName(meta.calendar.name);
  }, [meta.calendar?.name]); // eslint-disable-line react-hooks/exhaustive-deps

  if (meta.status === 'loading') return <Splash />;
  if (meta.status !== 'ready' || !meta.calendar) {
    return (
      <main className="center-page">
        <div className="login-card">
          <h1>멤버 정보를 열 수 없어요</h1>
          <Link to="/" className="btn btn-primary">
            내 캘린더로
          </Link>
        </div>
      </main>
    );
  }

  const cal = meta.calendar;
  const isAdmin = meta.isAdmin;
  const adminCount = meta.members.filter((m) => m.role === 'admin').length;
  const soleAdmin = isAdmin && adminCount === 1;

  const run = async (key: string, fn: () => Promise<void>, ok?: string) => {
    setBusy(key);
    try {
      await fn();
      if (ok) toast(ok, 'success');
    } catch (err) {
      toast(errorMessage(err), 'error');
    } finally {
      setBusy(null);
    }
  };

  const toggleRole = (m: Member) => {
    const next = m.role === 'admin' ? 'member' : 'admin';
    run(m.user_id, () => meta.setRole(m.user_id, next), next === 'admin' ? '관리자로 지정했어요.' : '관리자에서 해제했어요.');
  };

  const kick = async (m: Member) => {
    const n = await meta.countEventsBy(m.user_id);
    const ok = await confirm({
      title: `${m.profile?.nickname ?? '멤버'}님을 내보낼까요?`,
      message: (
        <>
          작성한 일정 <b>{n}개</b>도 함께 삭제돼요. 초대코드를 알고 있으면 다시 들어올 수 있으니, 필요하면 내보낸 뒤 초대코드를 새로 만드세요.
        </>
      ),
      confirmText: '내보내기',
      danger: true,
    });
    if (ok) run(m.user_id, () => meta.removeMember(m.user_id), '멤버를 내보냈어요.');
  };

  const leave = async () => {
    const ok = await confirm({
      title: '캘린더에서 나갈까요?',
      message: '내가 작성한 이 캘린더의 일정은 모두 삭제돼요.',
      confirmText: '나가기',
      danger: true,
    });
    if (!ok) return;
    setBusy('leave');
    try {
      await meta.removeMember(userId);
      toast('캘린더에서 나왔어요.', 'success');
      navigate('/', { replace: true });
    } catch (err) {
      toast(errorMessage(err), 'error');
      setBusy(null);
    }
  };

  const remove = async () => {
    const ok = await confirm({
      title: '캘린더를 삭제할까요?',
      message: '모든 멤버와 일정이 영구 삭제돼요. 되돌릴 수 없어요.',
      confirmText: '영구 삭제',
      danger: true,
      requireText: cal.name,
    });
    if (!ok) return;
    setBusy('delete');
    try {
      await meta.deleteCalendar();
      toast('캘린더를 삭제했어요.', 'success');
      navigate('/', { replace: true });
    } catch (err) {
      toast(errorMessage(err), 'error');
      setBusy(null);
    }
  };

  return (
    <div className="page narrow">
      <header className="topbar">
        <Link to={`/c/${calendarId}`} className="icon-btn" ariaLabel="캘린더로 돌아가기">
          <Icon name="chevron-left" />
        </Link>
        <div className="cal-name">
          <span>멤버 · {cal.name}</span>
        </div>
        <div className="top-actions" />
      </header>

      <section className="card">
        <h2 className="card-title">초대</h2>
        <div className="invite-row">
          <div>
            <div className="code-inline">{cal.invite_code}</div>
            <div className="muted small ellipsis">{inviteUrl(cal.invite_code)}</div>
          </div>
          <button type="button" className="btn btn-primary" onClick={() => setShareOpen(true)}>
            <Icon name="share" size={18} /> 공유
          </button>
        </div>
      </section>

      <section className="card">
        <h2 className="card-title">
          멤버 <span className="muted">{meta.members.length}명</span>
        </h2>
        <ul className="member-list">
          {meta.members.map((m) => {
            const color = m.profile?.color ?? GRAY;
            const me = m.user_id === userId;
            return (
              <li key={m.user_id} className="member">
                <span className="avatar" style={{ background: color, color: textOn(color) }}>
                  {[...(m.profile?.nickname ?? '?')][0]}
                </span>
                <div className="member-main">
                  <div className="member-name">
                    {m.profile?.nickname ?? '(이름 없음)'}
                    {me && <span className="muted small"> (나)</span>}
                    {m.role === 'admin' && <span className="badge badge-admin">관리자</span>}
                  </div>
                  <div className="muted small">{new Date(m.joined_at).toLocaleDateString('ko-KR')} 참여</div>
                </div>
                {isAdmin && !me && (
                  <div className="member-actions">
                    <button type="button" className="btn btn-small btn-ghost" disabled={busy === m.user_id} onClick={() => toggleRole(m)}>
                      {m.role === 'admin' ? '관리자 해제' : '관리자 지정'}
                    </button>
                    <button type="button" className="btn btn-small btn-ghost danger-text" disabled={busy === m.user_id} onClick={() => kick(m)}>
                      내보내기
                    </button>
                  </div>
                )}
              </li>
            );
          })}
        </ul>
        {!isAdmin && <p className="muted small">멤버 관리는 관리자만 할 수 있어요.</p>}
      </section>

      {isAdmin && (
        <section className="card">
          <h2 className="card-title">캘린더 설정</h2>
          <form
            className="stack"
            onSubmit={(e) => {
              e.preventDefault();
              const v = name.trim();
              if (v && v !== cal.name) run('name', () => meta.updateCalendar({ name: v }), '이름을 바꿨어요.');
            }}
          >
            <label className="field">
              <span className="field-label">캘린더 이름</span>
              <div className="copy-row">
                <input className="input" value={name} maxLength={30} onChange={(e) => setName(e.target.value)} />
                <button className="btn btn-ghost" disabled={!name.trim() || name.trim() === cal.name || busy === 'name'}>
                  저장
                </button>
              </div>
            </label>
          </form>
          <div className="field">
            <span className="field-label">단체 일정 강조색</span>
            <ColorPicker
              label="단체 일정 강조색"
              value={cal.group_color}
              colors={GROUP_COLORS}
              onChange={(c) => run('color', () => meta.updateCalendar({ group_color: c }))}
            />
          </div>
        </section>
      )}

      <section className="card danger-zone">
        <button
          type="button"
          className="btn btn-ghost danger-text btn-block"
          onClick={leave}
          disabled={busy === 'leave' || soleAdmin}
        >
          <Icon name="logout" size={18} /> 캘린더 나가기
        </button>
        {soleAdmin && (
          <p className="muted small">
            {meta.members.length > 1
              ? '유일한 관리자예요. 다른 멤버를 관리자로 지정해야 나갈 수 있어요.'
              : '혼자 남은 관리자예요. 캘린더가 더 필요 없다면 삭제해 주세요.'}
          </p>
        )}
        {isAdmin && (
          <button type="button" className="btn btn-danger btn-block" onClick={remove} disabled={busy === 'delete'}>
            <Icon name="trash" size={18} /> 캘린더 삭제
          </button>
        )}
      </section>

      <ShareSheet open={shareOpen} calendar={cal} isAdmin={isAdmin} onClose={() => setShareOpen(false)} onRegenerate={meta.regenerateCode} />
    </div>
  );
}
