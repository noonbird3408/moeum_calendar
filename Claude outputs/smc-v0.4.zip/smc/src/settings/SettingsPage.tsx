import { useState } from 'react';
import { useAuth } from '@/auth/AuthProvider';
import { ProfileForm } from '@/auth/ProfileForm';
import { deleteMyAccount, exportMyEventsIcs } from '@/lib/account';
import { setPrefs, usePrefs, type Prefs } from '@/lib/prefs';
import { useRouter } from '@/lib/router';
import { errorMessage } from '@/lib/supabase';
import { Icon } from '@/ui/Icon';
import { ColorPicker, Segmented, Toggle } from '@/ui/controls';
import { useFeedback } from '@/ui/Feedback';

const BUG_EMAIL = 'deleu1134@gmail.com';
const HIGHLIGHT_COLORS = ['#16a34a', '#059669', '#0ea5e9', '#2563eb', '#7c3aed', '#f59e0b', '#e11d48'];
const APP_VERSION = import.meta.env.VITE_APP_VERSION ?? 'dev';

export function reportBug() {
  const body = [
    '[증상]',
    '',
    '',
    '[재현 방법]',
    '1. ',
    '',
    '---',
    `화면: ${window.location.pathname}`,
    `브라우저: ${navigator.userAgent}`,
    `앱 버전: ${APP_VERSION}`,
    `시각: ${new Date().toLocaleString('ko-KR')}`,
  ].join('\n');
  window.location.href = `mailto:${BUG_EMAIL}?subject=${encodeURIComponent('[모음달력] 버그 신고')}&body=${encodeURIComponent(body)}`;
}

export function SettingsPage() {
  const { email, signOut, userId } = useAuth();
  const { back, navigate } = useRouter();
  const { confirm, toast } = useFeedback();
  const prefs = usePrefs();
  const [exporting, setExporting] = useState(false);
  const set = <K extends keyof Prefs>(k: K) => (v: Prefs[K]) => setPrefs({ [k]: v } as Partial<Prefs>);

  const logout = async () => {
    if (!(await confirm({ title: '로그아웃할까요?', confirmText: '로그아웃' }))) return;
    await signOut();
    navigate('/login', { replace: true });
  };

  const exportIcs = async () => {
    setExporting(true);
    try {
      const n = await exportMyEventsIcs(userId);
      toast(n ? `일정 ${n}개를 내보냈어요.` : '내보낼 일정이 없어요.', 'success');
    } catch (err) {
      toast(errorMessage(err), 'error');
    } finally {
      setExporting(false);
    }
  };

  const removeAccount = async () => {
    const ok = await confirm({
      title: '계정을 삭제할까요?',
      message: (
        <>
          <p>삭제하면 되돌릴 수 없어요.</p>
          <ul className="plain-list small">
            <li>참여한 모든 캘린더에서 자동으로 나가요.</li>
            <li>내가 작성한 일정은 모두 삭제돼요.</li>
            <li>내가 관리자였던 캘린더는 다른 멤버가 관리자를 이어받아요. 멤버가 나뿐이었다면 캘린더도 삭제돼요.</li>
            <li>프로필 사진과 계정 정보가 지워지고, 다음 접속 때는 로그인 화면부터 시작해요.</li>
          </ul>
          <p>계속하려면 아래 칸에 <b>삭제</b>를 입력하세요.</p>
        </>
      ),
      confirmText: '계정 삭제',
      danger: true,
      requireText: '삭제',
    });
    if (!ok) return;
    try {
      await deleteMyAccount(userId);
      toast('계정을 삭제했어요.', 'info');
      navigate('/login', { replace: true });
    } catch (err) {
      toast(errorMessage(err), 'error');
    }
  };

  return (
    <div className="page narrow">
      <header className="topbar">
        <button type="button" className="icon-btn" aria-label="뒤로" onClick={() => back('/')}>
          <Icon name="chevron-left" />
        </button>
        <div className="cal-name">
          <span>설정</span>
        </div>
        <div className="top-actions" />
      </header>

      <section className="card">
        <h2 className="card-title">프로필</h2>
        <ProfileForm submitText="프로필 저장" />
        <p className="muted small">{email} 로 로그인됨</p>
      </section>

      <section className="card">
        <h2 className="card-title">화면</h2>
        <div className="setting">
          <span>테마</span>
          <Segmented
            ariaLabel="테마"
            value={prefs.theme}
            onChange={set('theme')}
            options={[
              { value: 'system', label: '시스템' },
              { value: 'light', label: '라이트' },
              { value: 'dark', label: '다크' },
            ]}
          />
        </div>
        <div className="setting">
          <span>글자 크기</span>
          <Segmented
            ariaLabel="글자 크기"
            value={prefs.fontSize}
            onChange={set('fontSize')}
            options={[
              { value: 'sm', label: '작게' },
              { value: 'md', label: '보통' },
              { value: 'lg', label: '크게' },
            ]}
          />
        </div>
        <div className="setting">
          <span>글꼴</span>
          <Segmented
            ariaLabel="글꼴"
            value={prefs.font}
            onChange={set('font')}
            options={[
              { value: 'pretendard', label: '프리텐다드' },
              { value: 'nanum', label: '나눔고딕' },
              { value: 'system', label: '기본' },
            ]}
          />
        </div>
        <div className="setting">
          <span>주 시작 요일</span>
          <Segmented
            ariaLabel="주 시작 요일"
            value={prefs.weekStart === 1 ? 'mon' : 'sun'}
            onChange={(v) => setPrefs({ weekStart: v === 'mon' ? 1 : 0 })}
            options={[
              { value: 'sun', label: '일요일' },
              { value: 'mon', label: '월요일' },
            ]}
          />
        </div>
        <div className="setting">
          <span>모바일 기본 보기</span>
          <Segmented
            ariaLabel="모바일 기본 보기"
            value={prefs.mobileView}
            onChange={set('mobileView')}
            options={[
              { value: 'month', label: '달력' },
              { value: 'list', label: '목록' },
            ]}
          />
        </div>
        <div className="setting">
          <span>하루종일 가능 표시 색</span>
          <ColorPicker label="하루종일 가능 표시 색" value={prefs.fullColor} colors={HIGHLIGHT_COLORS} onChange={set('fullColor')} />
        </div>
        <div className="setting">
          <span>시간대 가능 표시 색</span>
          <ColorPicker label="시간대 가능 표시 색" value={prefs.partialColor} colors={HIGHLIGHT_COLORS} onChange={set('partialColor')} />
        </div>
        <Toggle label="개인 일정을 회색으로 표시" checked={prefs.grayPersonal} onChange={set('grayPersonal')} />
        <p className="muted small">화면 설정은 이 기기에만 저장돼요.</p>
      </section>

      <section className="card">
        <h2 className="card-title">데이터</h2>
        <button type="button" className="row-btn" onClick={exportIcs} disabled={exporting}>
          <Icon name="calendar" size={18} /> {exporting ? '내보내는 중…' : '내 일정 내보내기 (.ics)'}
          <span className="muted small">구글 캘린더 등으로 가져갈 수 있어요</span>
        </button>
      </section>

      <section className="card">
        <h2 className="card-title">기타</h2>
        <button type="button" className="row-btn" onClick={reportBug}>
          <Icon name="mail" size={18} /> 버그 신고 <span className="muted small">{BUG_EMAIL}</span>
        </button>
        <button type="button" className="row-btn danger-text" onClick={logout}>
          <Icon name="logout" size={18} /> 로그아웃
        </button>
      </section>

      <section className="card danger-zone">
        <h2 className="card-title">계정</h2>
        <p className="muted small">계정을 지우면 참여한 캘린더에서 나가고, 내 일정과 프로필 사진이 모두 삭제돼요.</p>
        <button type="button" className="btn btn-danger btn-block" onClick={removeAccount}>
          계정 삭제
        </button>
      </section>

      <p className="fine center">모음달력 v{APP_VERSION}</p>
    </div>
  );
}
