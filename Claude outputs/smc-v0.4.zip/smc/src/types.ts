export type Role = 'admin' | 'member';

export type Profile = {
  id: string;
  nickname: string | null;
  color: string;
  avatar_url: string | null;
  recent_colors?: string[];
};

export type Calendar = {
  id: string;
  name: string;
  invite_code: string;
  group_color: string;
  owner_id: string;
  created_at: string;
};

export type Member = {
  calendar_id: string;
  user_id: string;
  role: Role;
  joined_at: string;
  profile: Profile | null;
};

/** 리치 본문: 문단(배열) → 글자 조각(run). 조각마다 굵기·기울기·밑줄·색·글꼴을 가진다. HTML 을 저장하지 않는다(XSS 방지). */

export type CalendarEvent = {
  id: string;
  calendar_id: string;
  author_id: string;
  title: string;
  memo: string | null;
  is_group: boolean;
  is_recurring: boolean;
  start_date: string; // YYYY-MM-DD (반복 일정은 첫 날)
  end_date: string; // 반복 일정은 반복 종료일
  start_time: string | null; // HH:MM:SS, null = 하루종일
  end_time: string | null;
  repeat_weekdays: number[] | null; // 0(일)~6(토), 반복 일정만
  repeat_until: string | null;
  link_url: string | null;
  created_at: string;
  updated_at: string;
  /** 화면에 펼쳐 놓은 회차의 날짜 (반복 일정을 날짜마다 펼칠 때만 채움) */
  occ?: string;
};

export type EventInput = {
  title: string;
  memo: string | null;
  is_group: boolean;
  is_recurring: boolean;
  start_date: string;
  end_date: string;
  start_time: string | null;
  end_time: string | null;
  repeat_weekdays: number[] | null;
  repeat_until: string | null;
  link_url: string | null;
};

export type Participant = { user_id: string; profile: Profile | null };

export type Comment = {
  id: string;
  event_id: string;
  author_id: string;
  body: string;
  created_at: string;
  author: Profile | null;
};

/** 캘린더 공지사항 (관리자만 작성) */
export type Announcement = {
  id: string;
  calendar_id: string;
  author_id: string;
  title: string;
  body: string;
  created_at: string;
  updated_at: string;
  author?: Profile | null;
};
