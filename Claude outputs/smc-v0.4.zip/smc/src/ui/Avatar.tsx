// 프로필 사진 또는 이름 첫 글자(퍼스널 컬러 배경)
import type { Profile } from '@/types';
import { GRAY, textOn } from '@/lib/colors';

export function Avatar({ profile, size = 28, title }: { profile: Pick<Profile, 'nickname' | 'color' | 'avatar_url'> | null | undefined; size?: number; title?: string }) {
  const color = profile?.color ?? GRAY;
  const name = profile?.nickname ?? '?';
  if (profile?.avatar_url) {
    return <img className="avatar-img" src={profile.avatar_url} alt={title ?? name} style={{ width: size, height: size }} loading="lazy" />;
  }
  return (
    <span className="avatar-fallback" title={title ?? name} style={{ background: color, color: textOn(color), width: size, height: size, fontSize: Math.round(size * 0.45) }}>
      {[...name][0]}
    </span>
  );
}
